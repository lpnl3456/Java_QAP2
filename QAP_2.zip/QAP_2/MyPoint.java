

public class MyPoint {
    private int x;
    private int y;

    //Constructor to set defualt values for the point
    public MyPoint(){
        this.x = 0;
        this.y = 0;
    }

    ////Constructor to set values using two integers
    public MyPoint(int x, int y){
        this.x =x;
        this.y=y;

    }

    //Get the value of x
    public int getX() {
        return x;
    }

    //Get the value of y
    public int getY() {
        return y;
    }

    //Set the value of x
    public void setX(int x) {
        this.x = x;
    }

    //Set the value of y
    public void setY(int y) {
        this.y = y;
    }

    //Set values for both X and Y
    public void setXY(int x, int y){
        this.x = x;
        this.y = y;
    }

    //Method to format the values into a string
    public String toString() {
        return ("x: " + this.x + " y: " + this.y);
    }

    public double distance(int x, int y){
        int xDiff = this.x-x;
        int yDiff = this.y-y;
        return Math.sqrt(xDiff*xDiff + yDiff *yDiff);
    }

    public double distance(MyPoint MyPoint){
        int xDiff = this.x-MyPoint.x;
        int yDiff = this.y-MyPoint.y;
        return Math.sqrt(xDiff*xDiff + yDiff *yDiff);
    }

    public double distance(){
        int xDiff = this.x-0;
        int yDiff = this.y-0;
        return Math.sqrt(xDiff*xDiff + yDiff *yDiff);
    }
}
