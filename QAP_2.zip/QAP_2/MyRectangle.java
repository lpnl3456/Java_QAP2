public class MyRectangle {
    private MyPoint v1;
    private MyPoint v2;

    ////Constructor to set defualt values for the rectangle
    public MyRectangle(){
        v1 = new MyPoint(1,2);
        v2 = new MyPoint(2,1);
    }

    //Constructor to set values using integers
    public MyRectangle(int x1, int y1, int x2, int y2){
        v1 = new MyPoint(x1,y1);
        v2 = new MyPoint(x2,y2);
    }

    //Constructor to set values using two MyPoint objects
    public MyRectangle(MyPoint v1, MyPoint v2){
        this.v1 = v1;
        this.v2 = v2;
    }

    //Get the values of v1
    public MyPoint getV1() {
        return v1;
    }

    //Get the values of v2
    public MyPoint getV2() {
        return v2;
    }

    //Set the values of v1
    public void setV1(MyPoint v1) {
        this.v1 = v1;
    }

    //Set the values of v2
    public void setV2(MyPoint v2) {
        this.v2 = v2;
    }

    //Return the value x in v1
    public int getV1X(){
        return v1.getX();
    }
    //Return the value y in v1
    public int getV1Y(){
        return v1.getY();
    }

    //Return the value x in v2
    public int getV2X(){
        return v2.getX();
    }

    //Return the value y in v2
    public int getV2Y(){
        return v2.getY();
    }

    //Method to get the area of the rectangle
    public double getArea(){
        //Create a point for the third conner of the rectangle
        MyPoint v3 = new MyPoint(v1.getX(), v2.getY());

        //Get the height and length of the rectangle
        double height = v1.distance(v3);
        double length = v2.distance(v3);

        //Return the area
        return height*length;
    }

    //Method to get the perimeter of the rectangle
    public double getPerimeter(){

        //Create a point for the third conner of the rectangle
        MyPoint v3 = new MyPoint(v1.getX(), v2.getY());

        //Get the height and length of the rectangle
        double height = v1.distance(v3);
        double length = v2.distance(v3);

        //Return the perimeter of the rectangle
        return (height*2) + (length*2);
    }

    @Override
    //Method to formate the values into a string
    public String toString() {
        return ("MyRectangle[v1=(" + v1.getX() + "," + v1.getY() + "), v2=(" + v2.getX() + "," + v2.getY() +")]");
    }

}
