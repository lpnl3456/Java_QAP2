public class MyLine {
    private MyPoint begin;
    private MyPoint end;

    //Constructor to create a MyLine Object using intergers
    public MyLine(int x1, int y1, int x2, int y2){
        begin = new MyPoint(x1,y1);
        end = new MyPoint(x2,y2);
    }

     //Constructor to create a MyLine Object using two MyPoint objects
    public MyLine(MyPoint begin, MyPoint end){
        this.begin = new MyPoint(begin.getX(),begin.getY());
        this.end = new MyPoint(end.getX(), end.getY());
    }

    //Get the values of begin
    public MyPoint getBegin() {
        return begin;
    }

    //Set the vlaues of begin
    public void setBegin(MyPoint begin) {
        this.begin = begin;
    }

    //Get the values of end
    public MyPoint getEnd() {
        return end;
    }

    //Set the values of end
    public void setEnd(MyPoint end) {
        this.end = end;
    }

    //Get the x value in begin
    public int getBeginX(){
        return begin.getX();
    }

    //Set the x value in begin
    public void setBeginX(int x){
        begin.setX(x);
    }

    //Get the y value in begin
    public int getBeginY(){
        return begin.getY();
    }

    //Set the y value in begin
    public void setBeginY(int y){
        begin.setY(y);
    }

    //Get the x value in end
    public int getEndX(){
        return end.getX();
    }

    //Set the x value in end
    public void setEndX(int x){
        end.setX(x);
    }

    //Get the y value in end
    public int getEndY(){
        return end.getY();
    }

    //Set the y value in end
    public void setEndY(int y){
        end.setY(y);
    }

    //Get both x and y values in begin
    public int[] getBeginXY(){

        int xyBegin [] = {begin.getX(),begin.getY()};
        return xyBegin;
    }

    //Set both x and y values in begin
    public void setBeginXY(int x, int y){
        begin.setX(x);
        begin.setY(y);
    }

    //Get both x and y values in end
    public int[] getEndXY(){

        int xyEnd [] = {end.getX(),end.getY()};
        return xyEnd;
    }

    //Set both x and y values in end
    public void setEndXY(int x, int y){
        end.setX(x);
        end.setY(y);
    }

    //Method to get the length of the line
    public double getLength(){
        return begin.distance(end);
    }

    //Method to get the gradient of the line
    public double getGradient(){
        int xDiff = begin.getX()-end.getX();
        int yDiff = begin.getY()-end.getY();
        return Math.atan2(yDiff, xDiff);
    }

    //Method to diplay the values in a string
    public String toString() {
        return ("MyLine[begin=(" + begin.getX() + "," + begin.getY() + "),end=(" + end.getX() + "," + end.getY() + ")");
    }
}
