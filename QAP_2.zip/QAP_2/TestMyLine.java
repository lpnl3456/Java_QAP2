//Test the MyLine class
public class TestMyLine {
    public static void main(String[] args) {
        //Set the beginning and ending points
        MyPoint p1 = new MyPoint(3,6);
        MyPoint p2 = new MyPoint(5,6);

        //Set two lines using diffrent constructor
        MyLine l1 = new MyLine(p1,p2);
        MyLine l2 = new MyLine(12,16,18,16);

        //Print the values
        System.out.println(l1.toString());
        System.out.println(l2.toString());

        //Set the x and y values for the beggining of l1
        l1.setBeginX(7);
        l1.setBeginY(8);
        //Print the values in the beginning of l1 using  get methods
        System.out.println(l1.getBeginX());
        System.out.println(l1.getBeginY());

        //Set both values of x and y for the beginning
        l1.setBeginXY(12,18);

        //Print both x and y values using the getBeginYX method
        int newBeginPoint [] = l1.getBeginXY();
        System.out.println(newBeginPoint[0] + "," + newBeginPoint[1]);

        //Set the x and y values of the ending of l1
        l1.setEndX(12);
        l1.setEndY(18);

        //Print the values in ending of l1 using  get methods
        System.out.println(l1.getEndX());
        System.out.println(l1.getEndY());

        //Print both x and y values using the getEndYX method
        l1.setEndXY(20,19);
        int newEndPoint [] = l1.getEndXY();
        System.out.println(newEndPoint[0] + "," + newEndPoint[1]);

        //Get the length of the line
        System.out.println(l1.getLength());

        //Get the gradient of the line
        System.out.println(l1.getGradient());

        
    }
}
