public class Person {
    private String lastName;
    private String firstName;
    private Address home;

    //Constructor to set the values of the object
    public Person(String lastName, String firstName, Address home){
        this.lastName = lastName;
        this.firstName = firstName;
        this.home = home;
    }

    //Method to format the values into a string
    public String toString() {
        return(this.firstName + " " + this.lastName + ", " + this.home.toString());
    }
}
