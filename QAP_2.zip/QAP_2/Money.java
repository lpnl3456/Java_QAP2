public class Money {
    private long dollars;
    private long cents;

    //Constructor to create a Money object using a double
    public Money(double amount){
        //Get the amount in dollars
        dollars = Math.round(amount);

        //Get the amount in cents
        amount = amount - Math.round(amount);

        //Set cents using amount
        cents = Math.round(amount*100);
    }

    //Constructor to create a Money object using a Money object
    public Money (Money otherObject){
        this.dollars = otherObject.getDollars();
        this.cents = otherObject.getCents();
    }

    //Method to get the value of dollars
    public long getDollars() {
        return dollars;
    }

    //Method t get the value of cents
    public long getCents() {
        return cents;
    }

    //Method to add money to the object
    public Money add(Money otherObject){
        this.dollars = dollars + otherObject.getDollars();
        this.cents = this.cents + otherObject.getCents();
        return this;
    }
    //Method to subtract money from the object
    public Money subtract(Money otherObject){

        this.dollars = this.dollars - otherObject.getDollars();
        this.cents = this.cents - otherObject.getCents();
        return this;
    }

    //Compare method to determine if the value of the object is greater or less than another Money object
    public int compareTo(Money otherObject){

        //Return 1 if the dollors of the object is greater
        if(this.dollars > otherObject.getDollars()){
            return 1;
        }
        //Return 1 if the dollors of the object is equal and cents is greater
        else if (this.dollars == otherObject.getDollars() && this.cents > otherObject.getCents()){
            return 1;
        }

        //Return 0 if the two objects are the same
        else if (this.dollars == otherObject.getDollars() && this.cents == otherObject.getCents()){
            return 0;
        }

        //Return -1 if the object is less
        else{
            return -1;
        }
    }

    //Method to determine if The object is equal to another object
    public boolean equals(Money otherObject){

        //Return true if both objects are equal
        if(this.dollars == otherObject.getDollars() && this.cents ==otherObject.getCents())
        {
            return true;
        }

        //Return false if the two objects are not equal
        else{
            return false;
        }

        
    }
    @Override
    public String toString() {
        if(cents<10){
            return "$" + dollars + ".0" + cents;
        }
        return "$" + dollars + "." + cents;
    }

}
