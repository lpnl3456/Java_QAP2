public class CreditCard {
    private Money balance = new Money(0);
    private Money creditLimit;
    private Person owner;

    //Constructor to create a CreditCard object
    public CreditCard(Person newCreditCardHolder, Money limit){
        this.creditLimit = limit;
        this.owner = newCreditCardHolder;
    }

    //Method to get the balance
    public Money getBalance() {
        return balance;
    }

    //Method to get the credit limit
    public Money getCreditLimit() {
        return creditLimit;
    }

    //Method to display the personal details of the customer
    public String getPersonals() {
        return owner.toString();
    }

    //Method to charge the credit card
    public void charge(Money amount){
        //Add the amount charged to the balance
        balance.add(amount);

        //If the balance is greater then the credit limit, display an error and remove the amount charged
        if (creditLimit.equals(balance) == false && creditLimit.compareTo(balance) == -1){
            System.err.println("Exceeds credit limit");
            balance.subtract(amount);
        }
    }

    //Method to pay off the amount in balance
    public void payment(Money amount){

        //Subtract the balance by the amount
        balance.subtract(amount);

    }
}
