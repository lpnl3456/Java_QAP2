//test the MyRectangle class
public class TestMyRectangle {
    public static void main(String[] args) {
        //Create a Myrectangle object
        MyRectangle r1 = new MyRectangle(5,2,10,8);

        //Set the x and y values of v1
        MyPoint newPoint = new MyPoint(6,8);
        r1.setV1(newPoint);
        System.out.println(r1.getV1X());
        System.out.println(r1.getV1Y());

        //Set the x and y values of v2
        newPoint = new MyPoint(12,16);
        r1.setV2(newPoint);
        System.out.println(r1.getV2X());
        System.out.println(r1.getV2Y());

        //Get the area of the rectangle
        System.out.println(r1.getArea());

        //get the perimeter of the rectangle
        System.out.println(r1.getPerimeter());

        //Display the two points
        System.out.println(r1.toString());
    }
}
